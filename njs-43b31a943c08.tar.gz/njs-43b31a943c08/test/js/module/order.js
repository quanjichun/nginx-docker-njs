if (!globalThis.stages) {
    globalThis.stages = [];
}

globalThis.stages.push('order');

export default 1;
