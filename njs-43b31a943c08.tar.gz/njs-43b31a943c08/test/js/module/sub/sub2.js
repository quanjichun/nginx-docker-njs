function hash(crypto) {
    return hashlib.hash();
}

import hashlib from 'hash.js';

export default {hash};
