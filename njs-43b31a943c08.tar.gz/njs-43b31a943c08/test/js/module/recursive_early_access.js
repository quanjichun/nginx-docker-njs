import m from 'recursive_early_access.js';

m.a;

export default 42;
