function f() {
    return a;
}

export default {f};
